from django.apps import AppConfig


class CsvsConfig(AppConfig):
    name = 'csvs'
